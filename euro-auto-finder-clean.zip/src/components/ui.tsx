import React from 'react';
import Link from 'next/link';

// Define types for our components
type BrandCardProps = {
  name: string;
  slug: string;
  logoUrl?: string;
};

type RepairTypeCardProps = {
  name: string;
  slug: string;
  brandSlug: string;
  description?: string;
};

type ShopCardProps = {
  name: string;
  slug: string;
  rating: number;
  address: string;
  logoUrl?: string;
  isMtaApproved: boolean;
};

// Brand selection card component
export const BrandCard: React.FC<BrandCardProps> = ({ name, slug, logoUrl }) => {
  return (
    <Link href={`/brands/${slug}`} className="brand-card">
      <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
        <div className="flex flex-col items-center">
          {logoUrl ? (
            <div className="w-24 h-24 mb-4">
              <img 
                src={logoUrl} 
                alt={`${name} logo`} 
                className="w-full h-full object-contain"
              />
            </div>
          ) : (
            <div className="w-24 h-24 mb-4 bg-gray-200 rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-gray-500">{name.charAt(0)}</span>
            </div>
          )}
          <h3 className="text-xl font-semibold text-center">{name}</h3>
          <p className="mt-2 text-blue-600 font-medium">Find Specialists</p>
        </div>
      </div>
    </Link>
  );
};

// Repair type card component
export const RepairTypeCard: React.FC<RepairTypeCardProps> = ({ 
  name, 
  slug, 
  brandSlug,
  description 
}) => {
  return (
    <Link href={`/brands/${brandSlug}/repairs/${slug}`} className="repair-type-card">
      <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
        <h3 className="text-xl font-semibold mb-2">{name}</h3>
        {description && (
          <p className="text-gray-600 mb-4 line-clamp-2">{description}</p>
        )}
        <p className="text-blue-600 font-medium">View Specialists</p>
      </div>
    </Link>
  );
};

// Shop card component
export const ShopCard: React.FC<ShopCardProps> = ({ 
  name, 
  slug, 
  rating, 
  address,
  logoUrl,
  isMtaApproved
}) => {
  // Generate star rating display
  const renderStars = () => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(<span key={i} className="text-yellow-400">★</span>);
      } else if (i === fullStars + 1 && hasHalfStar) {
        stars.push(<span key={i} className="text-yellow-400">★</span>);
      } else {
        stars.push(<span key={i} className="text-gray-300">★</span>);
      }
    }
    
    return stars;
  };
  
  return (
    <div className="shop-card bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
      <div className="flex items-start">
        {logoUrl ? (
          <div className="w-16 h-16 mr-4 flex-shrink-0">
            <img 
              src={logoUrl} 
              alt={`${name} logo`} 
              className="w-full h-full object-contain"
            />
          </div>
        ) : (
          <div className="w-16 h-16 mr-4 bg-gray-200 rounded-full flex-shrink-0 flex items-center justify-center">
            <span className="text-xl font-bold text-gray-500">{name.charAt(0)}</span>
          </div>
        )}
        
        <div className="flex-grow">
          <div className="flex justify-between items-start">
            <h3 className="text-xl font-semibold">{name}</h3>
            {isMtaApproved && (
              <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium">
                MTA Approved
              </span>
            )}
          </div>
          
          <div className="flex items-center mt-1">
            <div className="flex mr-2">
              {renderStars()}
            </div>
            <span className="text-gray-600 text-sm">{rating.toFixed(1)}</span>
          </div>
          
          <p className="text-gray-600 mt-2">{address}</p>
          
          <div className="mt-4 flex space-x-3">
            <Link 
              href={`/shops/${slug}`}
              className="text-blue-600 font-medium hover:text-blue-800"
            >
              View Profile
            </Link>
            <Link 
              href={`/shops/${slug}/quote`}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors duration-300"
            >
              Request Quote
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

// How it works step component
type HowItWorksStepProps = {
  number: number;
  title: string;
  description: string;
  iconUrl?: string;
};

export const HowItWorksStep: React.FC<HowItWorksStepProps> = ({
  number,
  title,
  description,
  iconUrl
}) => {
  return (
    <div className="how-it-works-step flex flex-col items-center text-center">
      <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
        {iconUrl ? (
          <img src={iconUrl} alt={title} className="w-8 h-8" />
        ) : (
          <span className="text-2xl font-bold text-blue-600">{number}</span>
        )}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

// Testimonial component
type TestimonialProps = {
  name: string;
  vehicle: string;
  comment: string;
  rating: number;
  imageUrl?: string;
};

export const Testimonial: React.FC<TestimonialProps> = ({
  name,
  vehicle,
  comment,
  rating,
  imageUrl
}) => {
  // Generate star rating display
  const renderStars = () => {
    const stars = [];
    
    for (let i = 1; i <= 5; i++) {
      if (i <= rating) {
        stars.push(<span key={i} className="text-yellow-400">★</span>);
      } else {
        stars.push(<span key={i} className="text-gray-300">★</span>);
      }
    }
    
    return stars;
  };
  
  return (
    <div className="testimonial bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-4">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={name} 
            className="w-12 h-12 rounded-full mr-4"
          />
        ) : (
          <div className="w-12 h-12 bg-gray-200 rounded-full mr-4 flex items-center justify-center">
            <span className="text-lg font-bold text-gray-500">{name.charAt(0)}</span>
          </div>
        )}
        <div>
          <h4 className="font-semibold">{name}</h4>
          <p className="text-sm text-gray-600">{vehicle}</p>
        </div>
      </div>
      <div className="flex mb-3">
        {renderStars()}
      </div>
      <p className="text-gray-700 italic">"{comment}"</p>
    </div>
  );
};

// Quote request form step indicator
type FormStepIndicatorProps = {
  currentStep: number;
  totalSteps: number;
};

export const FormStepIndicator: React.FC<FormStepIndicatorProps> = ({
  currentStep,
  totalSteps
}) => {
  return (
    <div className="form-step-indicator mb-6">
      <div className="flex justify-between items-center">
        {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => (
          <div key={step} className="flex flex-col items-center">
            <div 
              className={`w-10 h-10 rounded-full flex items-center justify-center ${
                step < currentStep 
                  ? 'bg-green-500 text-white' 
                  : step === currentStep 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-500'
              }`}
            >
              {step < currentStep ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              ) : (
                step
              )}
            </div>
            <span className={`text-sm mt-1 ${step === currentStep ? 'font-semibold' : 'text-gray-500'}`}>
              Step {step}
            </span>
          </div>
        ))}
      </div>
      <div className="relative mt-2">
        <div className="absolute top-0 left-0 h-1 bg-gray-200 w-full"></div>
        <div 
          className="absolute top-0 left-0 h-1 bg-blue-600 transition-all duration-300"
          style={{ width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%` }}
        ></div>
      </div>
    </div>
  );
};

// Header component
export const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-blue-600">
            Euro Auto Finder
          </Link>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="text-gray-700 hover:text-blue-600">
              Home
            </Link>
            <Link href="/brands" className="text-gray-700 hover:text-blue-600">
              Brands
            </Link>
            <Link href="/shops" className="text-gray-700 hover:text-blue-600">
              Repair Shops
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-blue-600">
              About
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-blue-600">
              Contact
            </Link>
          </nav>
          <div className="md:hidden">
            <button className="text-gray-700">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

// Footer component
export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Euro Auto Finder</h3>
            <p className="text-gray-300">
              Connecting Auckland vehicle owners with trusted European auto specialists.
            </p>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-300 hover:text-white">Home</Link></li>
              <li><Link href="/brands" className="text-gray-300 hover:text-white">Brands</Link></li>
              <li><Link href="/shops" className="text-gray-300 hover:text-white">Repair Shops</Link></li>
              <li><Link href="/about" className="text-gray-300 hover:text-white">About Us</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Brands</h4>
            <ul className="space-y-2">
              <li><Link href="/brands/mercedes" className="text-gray-300 hover:text-white">Mercedes-Benz</Link></li>
              <li><Link href="/brands/bmw" className="text-gray-300 hover:text-white">BMW</Link></li>
              <li><Link href="/brands/audi" className="text-gray-300 hover:text-white">Audi</Link></li>
              <li><Link href="/brands/volkswagen" className="text-gray-300 hover:text-white">Volkswagen</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-gray-300">
              <li>Auckland, New Zealand</li>
              <li>info@euroautofinder.co.nz</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Euro Auto Finder. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
