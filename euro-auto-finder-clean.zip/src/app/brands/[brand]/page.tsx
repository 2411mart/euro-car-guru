import { Header, Footer, RepairTypeCard } from '@/components/ui';
import Link from 'next/link';

// This would be a dynamic page in production with [brand] parameter
export default function BrandPage() {
  // Mock data for a specific brand - in production this would come from the database
  const brand = {
    id: 1,
    name: 'Mercedes-Benz',
    slug: 'mercedes',
    logoUrl: '/images/mercedes-logo.png',
    description: 'Mercedes-Benz is a German global automobile marque and a division of Daimler AG. Mercedes-Benz is known for luxury vehicles, vans, trucks, buses, coaches and ambulances.'
  };
  
  // Mock data for repair types - in production this would come from the database
  const repairTypes = [
    { id: 1, name: 'Service & Maintenance', slug: 'service-maintenance', description: 'Regular servicing and maintenance to keep your Mercedes-Benz in optimal condition.' },
    { id: 2, name: 'Brakes & Suspension', slug: 'brakes-suspension', description: 'Repair and replacement of brake systems and suspension components.' },
    { id: 3, name: 'Engine & Transmission', slug: 'engine-transmission', description: 'Diagnostics and repair of engine and transmission systems.' },
    { id: 4, name: 'Electrical & Electronics', slug: 'electrical-electronics', description: 'Troubleshooting and repair of electrical systems and electronic components.' },
    { id: 5, name: 'Air Conditioning', slug: 'air-conditioning', description: 'Maintenance and repair of vehicle climate control systems.' },
    { id: 6, name: 'Diagnostics', slug: 'diagnostics', description: 'Comprehensive vehicle diagnostics to identify issues and recommend solutions.' }
  ];
  
  // Mock data for shops specializing in this brand - in production this would come from the database
  const shops = [
    { 
      id: 1, 
      name: 'European Auto Specialists', 
      slug: 'european-auto-specialists',
      rating: 5.0,
      address: '123 Auto Lane, Auckland',
      isMtaApproved: true
    },
    { 
      id: 2, 
      name: 'Mercedes Masters', 
      slug: 'mercedes-masters',
      rating: 4.8,
      address: '456 Repair Road, Auckland',
      isMtaApproved: true
    },
    { 
      id: 3, 
      name: 'German Auto Care', 
      slug: 'german-auto-care',
      rating: 4.7,
      address: '789 Service Street, Auckland',
      isMtaApproved: true
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        {/* Brand Hero Section */}
        <section className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/3 mb-8 md:mb-0 flex justify-center">
                {brand.logoUrl ? (
                  <div className="w-48 h-48 bg-white rounded-full p-4 flex items-center justify-center">
                    <img 
                      src={brand.logoUrl} 
                      alt={`${brand.name} logo`} 
                      className="w-32 h-32 object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-48 h-48 bg-white rounded-full flex items-center justify-center">
                    <span className="text-6xl font-bold text-blue-700">{brand.name.charAt(0)}</span>
                  </div>
                )}
              </div>
              <div className="md:w-2/3 text-center md:text-left">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">
                  {brand.name} Repair Specialists in Auckland
                </h1>
                <p className="text-xl mb-6">
                  Find trusted, MTA-approved independent repair shops that specialize in {brand.name} vehicles.
                </p>
                <Link 
                  href="#repair-types" 
                  className="bg-white text-blue-700 px-6 py-3 rounded-md font-semibold hover:bg-blue-50 transition-colors"
                >
                  Explore Services
                </Link>
              </div>
            </div>
          </div>
        </section>
        
        {/* Brand Information Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-6">About {brand.name} Vehicles</h2>
              <p className="text-gray-700 mb-6">
                {brand.description}
              </p>
              <h3 className="text-2xl font-semibold mb-4">Common {brand.name} Issues</h3>
              <div className="bg-white rounded-lg shadow-md p-6">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <div>
                      <h4 className="font-semibold">Electrical System Issues</h4>
                      <p className="text-gray-600">Mercedes vehicles often experience electrical problems, including issues with the central locking system, power windows, and dashboard electronics.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <div>
                      <h4 className="font-semibold">Oil Leaks</h4>
                      <p className="text-gray-600">Oil leaks from the valve cover gaskets and oil pan gaskets are common in older Mercedes models.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <div>
                      <h4 className="font-semibold">Suspension Problems</h4>
                      <p className="text-gray-600">The air suspension system in Mercedes vehicles can develop leaks and compressor failures over time.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
        
        {/* Repair Types Section */}
        <section id="repair-types" className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Select Your Repair Type</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {repairTypes.map((repairType) => (
                <RepairTypeCard 
                  key={repairType.id}
                  name={repairType.name}
                  slug={repairType.slug}
                  brandSlug={brand.slug}
                  description={repairType.description}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* Top Specialists Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-4">
              Top {brand.name} Specialists in Auckland
            </h2>
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              These MTA-approved repair shops specialize in {brand.name} vehicles and provide exceptional service.
            </p>
            
            <div className="space-y-6 max-w-4xl mx-auto">
              {shops.map((shop) => (
                <div key={shop.id} className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex flex-col md:flex-row md:items-center">
                    <div className="md:w-3/4">
                      <div className="flex items-start">
                        <div>
                          <h3 className="text-xl font-semibold">{shop.name}</h3>
                          <div className="flex items-center mt-1">
                            <div className="flex text-yellow-400">
                              <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                            </div>
                            <span className="text-gray-600 ml-2">{shop.rating.toFixed(1)}</span>
                            {shop.isMtaApproved && (
                              <span className="ml-3 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium">
                                MTA Approved
                              </span>
                            )}
                          </div>
                          <p className="text-gray-600 mt-2">{shop.address}</p>
                          <p className="mt-3 text-gray-700">
                            Specializing in all {brand.name} models with factory-trained technicians and the latest diagnostic equipment.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="md:w-1/4 mt-4 md:mt-0 flex flex-col space-y-3 md:items-end">
                      <Link 
                        href={`/shops/${shop.slug}`}
                        className="text-blue-600 font-medium hover:text-blue-800"
                      >
                        View Profile
                      </Link>
                      <Link 
                        href={`/shops/${shop.slug}/quote`}
                        className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors duration-300 text-center"
                      >
                        Request Quote
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-10">
              <Link 
                href={`/brands/${brand.slug}/shops`}
                className="bg-blue-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition-colors"
              >
                View All {brand.name} Specialists
              </Link>
            </div>
          </div>
        </section>
        
        {/* Testimonials Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              What {brand.name} Owners Say
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full mr-4 flex items-center justify-center">
                    <span className="text-lg font-bold text-gray-500">J</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">John Smith</h4>
                    <p className="text-sm text-gray-600">Mercedes-Benz C-Class</p>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-3">
                  <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                </div>
                <p className="text-gray-700 italic">"Found an amazing specialist through Euro Auto Finder. They diagnosed and fixed an electrical issue that the dealership couldn't solve. Highly recommended!"</p>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full mr-4 flex items-center justify-center">
                    <span className="text-lg font-bold text-gray-500">S</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Sarah Johnson</h4>
                    <p className="text-sm text-gray-600">Mercedes-Benz GLC</p>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-3">
                  <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                </div>
                <p className="text-gray-700 italic">"The shop I found through this site saved me hundreds compared to the dealership quote. Same quality service but much more personal attention."</p>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full mr-4 flex items-center justify-center">
                    <span className="text-lg font-bold text-gray-500">D</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">David Williams</h4>
                    <p className="text-sm text-gray-600">Mercedes-Benz E-Class</p>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-3">
                  <span>★</span><span>★</span><span>★</span><span>★</span><span className="text-gray-300">★</span>
                </div>
                <p className="text-gray-700 italic">"Quick response to my quote request and excellent service. The mechanic explained everything clearly and fixed my suspension issues perfectly."</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-blue-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Service Your {brand.name}?</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Get connected with trusted, MTA-approved repair shops in Auckland that specialize in {brand.name} vehicles.
            </p>
            <Link 
              href="#repair-types" 
              className="bg-white text-blue-700 px-6 py-3 rounded-md font-semibold hover:bg-blue-50 transition-colors"
            >
              Find a Specialist Now
            </Link>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
