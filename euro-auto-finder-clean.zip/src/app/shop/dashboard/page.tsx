import { Header, Footer } from '@/components/ui';
import Link from 'next/link';

export default function ShopDashboardPage() {
  // In a real implementation, this would be a client component with state management
  // For this static example, we'll show a mock shop dashboard
  
  // Mock data for a shop - in production this would come from the database
  const shop = {
    id: 1,
    name: 'European Auto Specialists',
    email: 'info@euroautospecialists.co.nz',
    phone: '09-123-4567',
    address: '123 Auto Lane, Auckland',
    isMtaApproved: true
  };
  
  // Mock data for leads - in production this would come from the database
  const leads = [
    { 
      id: 1, 
      referenceCode: 'EAF12345', 
      customerName: 'John Smith',
      customerEmail: 'john.smith@example.com',
      customerPhone: '021-555-1234',
      vehicleBrand: 'Mercedes-Benz',
      vehicleModel: 'C-Class',
      vehicleYear: '2018',
      repairType: 'Service & Maintenance',
      description: 'Regular service and oil change needed',
      status: 'Completed',
      date: '2025-04-20',
      isCompleted: true,
      commission: 45.00
    },
    { 
      id: 2, 
      referenceCode: 'EAF12346', 
      customerName: 'Sarah Johnson',
      customerEmail: 'sarah.j@example.com',
      customerPhone: '022-555-5678',
      vehicleBrand: 'BMW',
      vehicleModel: '3 Series',
      vehicleYear: '2020',
      repairType: 'Brakes & Suspension',
      description: 'Squeaking noise when braking',
      status: 'In Progress',
      date: '2025-04-23',
      isCompleted: false,
      commission: null
    },
    { 
      id: 3, 
      referenceCode: 'EAF12347', 
      customerName: 'David Williams',
      customerEmail: 'david.w@example.com',
      customerPhone: '027-555-9012',
      vehicleBrand: 'Mercedes-Benz',
      vehicleModel: 'E-Class',
      vehicleYear: '2019',
      repairType: 'Electrical & Electronics',
      description: 'Dashboard warning lights coming on intermittently',
      status: 'New',
      date: '2025-04-25',
      isCompleted: false,
      commission: null
    }
  ];
  
  // Calculate statistics
  const newLeads = leads.filter(lead => lead.status === 'New').length;
  const inProgressLeads = leads.filter(lead => lead.status === 'In Progress').length;
  const completedLeads = leads.filter(lead => lead.isCompleted).length;
  const totalCommission = leads
    .filter(lead => lead.commission !== null)
    .reduce((sum, lead) => sum + (lead.commission || 0), 0);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold mb-2">{shop.name} Dashboard</h1>
                <p className="text-gray-600">Manage your leads and track commissions</p>
              </div>
              <div className="mt-4 md:mt-0">
                <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                  Update Profile
                </button>
              </div>
            </div>
            
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-blue-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-blue-800 mb-2">New Leads</h3>
                <p className="text-3xl font-bold">{newLeads}</p>
                <p className="text-sm text-blue-600 mt-2">Awaiting response</p>
              </div>
              
              <div className="bg-yellow-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-yellow-800 mb-2">In Progress</h3>
                <p className="text-3xl font-bold">{inProgressLeads}</p>
                <p className="text-sm text-yellow-600 mt-2">Currently working</p>
              </div>
              
              <div className="bg-green-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-green-800 mb-2">Completed Jobs</h3>
                <p className="text-3xl font-bold">{completedLeads}</p>
                <p className="text-sm text-green-600 mt-2">All time</p>
              </div>
              
              <div className="bg-purple-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-purple-800 mb-2">Total Commission</h3>
                <p className="text-3xl font-bold">${totalCommission.toFixed(2)}</p>
                <p className="text-sm text-purple-600 mt-2">Paid to Euro Auto Finder</p>
              </div>
            </div>
            
            {/* Lead Verification Section */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Complete a Job</h2>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex flex-col md:flex-row md:items-end space-y-4 md:space-y-0 md:space-x-4">
                  <div className="flex-grow">
                    <label htmlFor="referenceCode" className="block text-gray-700 font-medium mb-2">
                      Reference Code
                    </label>
                    <input 
                      type="text" 
                      id="referenceCode" 
                      placeholder="Enter customer's reference code"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <button className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors">
                    Mark as Completed
                  </button>
                </div>
                <p className="text-sm text-gray-500 mt-3">
                  Enter the reference code provided by the customer to mark the job as completed. This will trigger the commission payment to Euro Auto Finder.
                </p>
              </div>
            </div>
            
            {/* Tabs for different lead statuses */}
            <div className="mb-6">
              <div className="border-b border-gray-200">
                <nav className="-mb-px flex space-x-8">
                  <button className="border-blue-500 text-blue-600 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    All Leads ({leads.length})
                  </button>
                  <button className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    New ({newLeads})
                  </button>
                  <button className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    In Progress ({inProgressLeads})
                  </button>
                  <button className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    Completed ({completedLeads})
                  </button>
                </nav>
              </div>
            </div>
            
            {/* Leads List */}
            <div>
              {leads.map(lead => (
                <div key={lead.id} className="border-b border-gray-200 py-6 last:border-b-0">
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-3/4">
                      <div className="flex items-start">
                        <div className="flex-grow">
                          <div className="flex items-center">
                            <h3 className="text-lg font-semibold">{lead.customerName}</h3>
                            <span className={`ml-3 px-2 py-1 rounded-full text-xs font-medium ${
                              lead.status === 'Completed' 
                                ? 'bg-green-100 text-green-800' 
                                : lead.status === 'In Progress'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-blue-100 text-blue-800'
                            }`}>
                              {lead.status}
                            </span>
                          </div>
                          <p className="text-gray-600 mt-1">
                            <span className="font-medium">Reference:</span> {lead.referenceCode}
                          </p>
                          <p className="text-gray-600">
                            <span className="font-medium">Vehicle:</span> {lead.vehicleBrand} {lead.vehicleModel} ({lead.vehicleYear})
                          </p>
                          <p className="text-gray-600">
                            <span className="font-medium">Service:</span> {lead.repairType}
                          </p>
                          <p className="text-gray-600">
                            <span className="font-medium">Description:</span> {lead.description}
                          </p>
                          <div className="mt-3">
                            <p className="text-gray-600">
                              <span className="font-medium">Contact:</span> {lead.customerEmail} | {lead.customerPhone}
                            </p>
                            <p className="text-gray-600">
                              <span className="font-medium">Date:</span> {lead.date}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="md:w-1/4 mt-4 md:mt-0 flex flex-col space-y-3 md:items-end">
                      {lead.isCompleted ? (
                        <div className="text-right">
                          <p className="text-gray-600">Commission Paid:</p>
                          <p className="text-xl font-bold text-green-600">${lead.commission?.toFixed(2)}</p>
                        </div>
                      ) : (
                        <>
                          {lead.status === 'New' && (
                            <>
                              <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                                Accept Lead
                              </button>
                              <button className="border border-red-600 text-red-600 px-4 py-2 rounded-md hover:bg-red-50 transition-colors">
                                Decline
                              </button>
                            </>
                          )}
                          {lead.status === 'In Progress' && (
                            <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors">
                              Mark Completed
                            </button>
                          )}
                          <button className="text-blue-600 hover:text-blue-800">
                            Contact Customer
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
