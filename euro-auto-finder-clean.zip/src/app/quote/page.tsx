import { Header, Footer, FormStepIndicator } from '@/components/ui';
import Link from 'next/link';

export default function QuoteRequestPage() {
  // In a real implementation, this would be a client component with state management
  // For this static example, we'll show the first step of the form
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-8">
            <h1 className="text-3xl font-bold text-center mb-6">Request a Quote</h1>
            <p className="text-center text-gray-600 mb-8">
              Fill out the form below to get quotes from trusted European auto specialists in Auckland.
            </p>
            
            <FormStepIndicator currentStep={1} totalSteps={3} />
            
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Step 1: Vehicle Details</h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="brand" className="block text-gray-700 font-medium mb-2">
                    Vehicle Brand
                  </label>
                  <select 
                    id="brand" 
                    name="brand"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Brand</option>
                    <option value="mercedes">Mercedes-Benz</option>
                    <option value="bmw">BMW</option>
                    <option value="audi">Audi</option>
                    <option value="volkswagen">Volkswagen</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="model" className="block text-gray-700 font-medium mb-2">
                    Vehicle Model
                  </label>
                  <input 
                    type="text" 
                    id="model" 
                    name="model"
                    placeholder="e.g., C-Class, 3 Series, A4, Golf"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="year" className="block text-gray-700 font-medium mb-2">
                    Vehicle Year
                  </label>
                  <select 
                    id="year" 
                    name="year"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Year</option>
                    {/* Generate years from current year back to 1990 */}
                    {Array.from({ length: 36 }, (_, i) => new Date().getFullYear() - i).map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label htmlFor="registration" className="block text-gray-700 font-medium mb-2">
                    Registration Number (Optional)
                  </label>
                  <input 
                    type="text" 
                    id="registration" 
                    name="registration"
                    placeholder="e.g., ABC123"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <button 
                type="button"
                className="bg-blue-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition-colors"
              >
                Next Step
              </button>
            </div>
            
            {/* Step 2 and 3 would be shown conditionally based on state in a real implementation */}
            <div className="hidden">
              <h2 className="text-xl font-semibold mb-4">Step 2: Repair Details</h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="repairType" className="block text-gray-700 font-medium mb-2">
                    Repair Type
                  </label>
                  <select 
                    id="repairType" 
                    name="repairType"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Repair Type</option>
                    <option value="service-maintenance">Service & Maintenance</option>
                    <option value="brakes-suspension">Brakes & Suspension</option>
                    <option value="engine-transmission">Engine & Transmission</option>
                    <option value="electrical-electronics">Electrical & Electronics</option>
                    <option value="air-conditioning">Air Conditioning</option>
                    <option value="diagnostics">Diagnostics</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                    Description of Issue
                  </label>
                  <textarea 
                    id="description" 
                    name="description"
                    rows={4}
                    placeholder="Please describe the issue you're experiencing with your vehicle..."
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  ></textarea>
                </div>
                
                <div>
                  <label htmlFor="urgency" className="block text-gray-700 font-medium mb-2">
                    Urgency
                  </label>
                  <select 
                    id="urgency" 
                    name="urgency"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="low">Not Urgent - Within a few weeks</option>
                    <option value="medium">Somewhat Urgent - Within a week</option>
                    <option value="high">Very Urgent - As soon as possible</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="timeframe" className="block text-gray-700 font-medium mb-2">
                    Preferred Timeframe
                  </label>
                  <select 
                    id="timeframe" 
                    name="timeframe"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="weekday">Weekday</option>
                    <option value="weekend">Weekend</option>
                    <option value="morning">Morning</option>
                    <option value="afternoon">Afternoon</option>
                    <option value="anytime">Anytime</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div className="hidden">
              <h2 className="text-xl font-semibold mb-4">Step 3: Contact Information</h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                    Full Name
                  </label>
                  <input 
                    type="text" 
                    id="name" 
                    name="name"
                    placeholder="Your full name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                    Email Address
                  </label>
                  <input 
                    type="email" 
                    id="email" 
                    name="email"
                    placeholder="Your email address"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
                    Phone Number
                  </label>
                  <input 
                    type="tel" 
                    id="phone" 
                    name="phone"
                    placeholder="Your phone number"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 font-medium mb-2">
                    Preferred Contact Method
                  </label>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <input 
                        type="radio" 
                        id="contactEmail" 
                        name="contactMethod"
                        value="email"
                        className="mr-2"
                      />
                      <label htmlFor="contactEmail">Email</label>
                    </div>
                    <div className="flex items-center">
                      <input 
                        type="radio" 
                        id="contactPhone" 
                        name="contactMethod"
                        value="phone"
                        className="mr-2"
                      />
                      <label htmlFor="contactPhone">Phone</label>
                    </div>
                    <div className="flex items-center">
                      <input 
                        type="radio" 
                        id="contactText" 
                        name="contactMethod"
                        value="text"
                        className="mr-2"
                      />
                      <label htmlFor="contactText">Text Message</label>
                    </div>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="notes" className="block text-gray-700 font-medium mb-2">
                    Additional Notes (Optional)
                  </label>
                  <textarea 
                    id="notes" 
                    name="notes"
                    rows={3}
                    placeholder="Any additional information you'd like to provide..."
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  ></textarea>
                </div>
              </div>
            </div>
            
            <div className="hidden">
              <div className="text-center py-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-green-600 mb-4">Quote Request Submitted!</h2>
                <p className="text-gray-600 mb-4">
                  Thank you! Your quote request has been sent to our network of European auto specialists.
                </p>
                <div className="bg-gray-50 p-4 rounded-md mb-6">
                  <p className="font-semibold mb-2">Your reference code:</p>
                  <p className="text-2xl font-bold text-blue-600 mb-2">EAF12345</p>
                  <p className="text-sm text-gray-500">
                    Please provide this code to the repair shop after service completion.
                  </p>
                </div>
                <div className="mb-8">
                  <h3 className="font-semibold mb-2">What happens next:</h3>
                  <ol className="text-left space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <span className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                        <span className="text-blue-600 font-semibold">1</span>
                      </span>
                      Repair shops will review your request within 24 hours
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                        <span className="text-blue-600 font-semibold">2</span>
                      </span>
                      You'll be contacted by the shops via your preferred method
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                        <span className="text-blue-600 font-semibold">3</span>
                      </span>
                      Choose your preferred shop and schedule your service
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                        <span className="text-blue-600 font-semibold">4</span>
                      </span>
                      After service completion, provide your reference code to the shop
                    </li>
                  </ol>
                </div>
                <Link 
                  href="/"
                  className="bg-blue-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition-colors"
                >
                  Return to Home
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
