import { Header, Footer, BrandCard } from '@/components/ui';
import Link from 'next/link';

export default function Home() {
  // Mock data for brands - in production this would come from the database
  const brands = [
    { id: 1, name: 'Mercedes-Benz', slug: 'mercedes', logoUrl: '/images/mercedes-logo.png' },
    { id: 2, name: 'BMW', slug: 'bmw', logoUrl: '/images/bmw-logo.png' },
    { id: 3, name: 'Audi', slug: 'audi', logoUrl: '/images/audi-logo.png' },
    { id: 4, name: 'Volkswagen', slug: 'volkswagen', logoUrl: '/images/volkswagen-logo.png' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Find Trusted European Auto Specialists in Auckland
            </h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Connect with top-rated, MTA-approved independent repair shops specializing in Mercedes, BMW, Audi, and Volkswagen.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link 
                href="#brands" 
                className="bg-white text-blue-700 px-6 py-3 rounded-md font-semibold hover:bg-blue-50 transition-colors"
              >
                Find a Specialist
              </Link>
              <Link 
                href="/about" 
                className="border-2 border-white text-white px-6 py-3 rounded-md font-semibold hover:bg-white hover:bg-opacity-10 transition-colors"
              >
                How It Works
              </Link>
            </div>
          </div>
        </section>
        
        {/* Brand Selection Section */}
        <section id="brands" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Select Your Vehicle Brand</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {brands.map((brand) => (
                <BrandCard 
                  key={brand.id}
                  name={brand.name}
                  slug={brand.slug}
                  logoUrl={brand.logoUrl}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* How It Works Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-600">1</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Select Your Brand</h3>
                <p className="text-gray-600">Choose your European vehicle brand from our selection.</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-600">2</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Choose Repair Type</h3>
                <p className="text-gray-600">Select the type of service or repair you need.</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-600">3</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Get Quotes</h3>
                <p className="text-gray-600">Receive quotes from trusted specialist workshops.</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-600">4</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Book Service</h3>
                <p className="text-gray-600">Choose your preferred shop and get your vehicle serviced.</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Trust Indicators Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">MTA Approved Shops</h3>
                <p className="text-gray-600">All repair shops are MTA approved, ensuring quality service and adherence to industry standards.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">European Vehicle Specialists</h3>
                <p className="text-gray-600">Our network consists of workshops that specialize in European vehicles, with expertise in your specific brand.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Independent Workshops</h3>
                <p className="text-gray-600">We partner with independent, non-franchise repair shops that provide personalized service at competitive rates.</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Featured Shops Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-4">Featured Repair Shops</h2>
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              These top-rated European vehicle specialists in Auckland are ready to help with your automotive needs.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* This would be populated from the database in production */}
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">European Auto Specialists</h3>
                  <div className="flex text-yellow-400 mb-2">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                    <span className="text-gray-600 ml-2">5.0</span>
                  </div>
                  <p className="text-gray-600 mb-4">Specializing in Mercedes-Benz and BMW repairs with over 15 years of experience.</p>
                  <Link 
                    href="/shops/european-auto-specialists" 
                    className="text-blue-600 font-medium hover:text-blue-800"
                  >
                    View Profile
                  </Link>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Audi & VW Experts</h3>
                  <div className="flex text-yellow-400 mb-2">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span className="text-gray-300">★</span>
                    <span className="text-gray-600 ml-2">4.8</span>
                  </div>
                  <p className="text-gray-600 mb-4">Auckland's premier independent Audi and Volkswagen service center.</p>
                  <Link 
                    href="/shops/audi-vw-experts" 
                    className="text-blue-600 font-medium hover:text-blue-800"
                  >
                    View Profile
                  </Link>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">German Auto Care</h3>
                  <div className="flex text-yellow-400 mb-2">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span className="text-gray-300">★</span>
                    <span className="text-gray-600 ml-2">4.7</span>
                  </div>
                  <p className="text-gray-600 mb-4">Comprehensive service for all German vehicles with factory-trained technicians.</p>
                  <Link 
                    href="/shops/german-auto-care" 
                    className="text-blue-600 font-medium hover:text-blue-800"
                  >
                    View Profile
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="text-center mt-10">
              <Link 
                href="/shops" 
                className="bg-blue-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition-colors"
              >
                View All Repair Shops
              </Link>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-blue-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Find Your European Auto Specialist?</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Get connected with trusted, MTA-approved repair shops in Auckland that specialize in your vehicle brand.
            </p>
            <Link 
              href="#brands" 
              className="bg-white text-blue-700 px-6 py-3 rounded-md font-semibold hover:bg-blue-50 transition-colors"
            >
              Find a Specialist Now
            </Link>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
