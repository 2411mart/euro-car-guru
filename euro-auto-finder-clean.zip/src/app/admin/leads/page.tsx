import { Header, Footer } from '@/components/ui';
import Link from 'next/link';

export default function LeadTrackingPage() {
  // In a real implementation, this would be a client component with state management
  // For this static example, we'll show a mock lead tracking dashboard
  
  // Mock data for leads - in production this would come from the database
  const leads = [
    { 
      id: 1, 
      referenceCode: 'EAF12345', 
      customerName: 'John Smith',
      vehicleBrand: 'Mercedes-Benz',
      vehicleModel: 'C-Class',
      repairType: 'Service & Maintenance',
      shopName: 'European Auto Specialists',
      status: 'Completed',
      date: '2025-04-20',
      commission: 45.00
    },
    { 
      id: 2, 
      referenceCode: 'EAF12346', 
      customerName: 'Sarah Johnson',
      vehicleBrand: 'BMW',
      vehicleModel: '3 Series',
      repairType: 'Brakes & Suspension',
      shopName: 'German Auto Care',
      status: 'In Progress',
      date: '2025-04-23',
      commission: null
    },
    { 
      id: 3, 
      referenceCode: 'EAF12347', 
      customerName: 'David Williams',
      vehicleBrand: 'Audi',
      vehicleModel: 'A4',
      repairType: 'Electrical & Electronics',
      shopName: 'Audi & VW Experts',
      status: 'Quoted',
      date: '2025-04-25',
      commission: null
    }
  ];
  
  // Calculate total commission
  const totalCommission = leads
    .filter(lead => lead.commission !== null)
    .reduce((sum, lead) => sum + (lead.commission || 0), 0);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
              <h1 className="text-3xl font-bold mb-4 md:mb-0">Lead Tracking Dashboard</h1>
              <div className="flex space-x-4">
                <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                  Export Data
                </button>
                <button className="border border-blue-600 text-blue-600 px-4 py-2 rounded-md hover:bg-blue-50 transition-colors">
                  Settings
                </button>
              </div>
            </div>
            
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-blue-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-blue-800 mb-2">Total Leads</h3>
                <p className="text-3xl font-bold">{leads.length}</p>
                <p className="text-sm text-blue-600 mt-2">All time</p>
              </div>
              
              <div className="bg-green-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-green-800 mb-2">Completed Jobs</h3>
                <p className="text-3xl font-bold">{leads.filter(lead => lead.status === 'Completed').length}</p>
                <p className="text-sm text-green-600 mt-2">All time</p>
              </div>
              
              <div className="bg-purple-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-purple-800 mb-2">Total Commission</h3>
                <p className="text-3xl font-bold">${totalCommission.toFixed(2)}</p>
                <p className="text-sm text-purple-600 mt-2">All time</p>
              </div>
            </div>
            
            {/* Lead Verification Section */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Verify Completed Job</h2>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex flex-col md:flex-row md:items-end space-y-4 md:space-y-0 md:space-x-4">
                  <div className="flex-grow">
                    <label htmlFor="referenceCode" className="block text-gray-700 font-medium mb-2">
                      Reference Code
                    </label>
                    <input 
                      type="text" 
                      id="referenceCode" 
                      placeholder="Enter reference code (e.g., EAF12345)"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <button className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors">
                    Verify Job
                  </button>
                </div>
                <p className="text-sm text-gray-500 mt-3">
                  Enter the reference code provided by the customer to verify job completion and calculate commission.
                </p>
              </div>
            </div>
            
            {/* Leads Table */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Recent Leads</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr className="bg-gray-100 text-gray-700 text-sm uppercase font-semibold">
                      <th className="py-3 px-4 text-left">Ref Code</th>
                      <th className="py-3 px-4 text-left">Customer</th>
                      <th className="py-3 px-4 text-left">Vehicle</th>
                      <th className="py-3 px-4 text-left">Repair Type</th>
                      <th className="py-3 px-4 text-left">Shop</th>
                      <th className="py-3 px-4 text-left">Date</th>
                      <th className="py-3 px-4 text-left">Status</th>
                      <th className="py-3 px-4 text-left">Commission</th>
                      <th className="py-3 px-4 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {leads.map(lead => (
                      <tr key={lead.id} className="hover:bg-gray-50">
                        <td className="py-3 px-4 font-medium">{lead.referenceCode}</td>
                        <td className="py-3 px-4">{lead.customerName}</td>
                        <td className="py-3 px-4">{lead.vehicleBrand} {lead.vehicleModel}</td>
                        <td className="py-3 px-4">{lead.repairType}</td>
                        <td className="py-3 px-4">{lead.shopName}</td>
                        <td className="py-3 px-4">{lead.date}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            lead.status === 'Completed' 
                              ? 'bg-green-100 text-green-800' 
                              : lead.status === 'In Progress'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {lead.status}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {lead.commission !== null ? `$${lead.commission.toFixed(2)}` : '-'}
                        </td>
                        <td className="py-3 px-4">
                          <button className="text-blue-600 hover:text-blue-800 mr-3">
                            View
                          </button>
                          {lead.status !== 'Completed' && (
                            <button className="text-green-600 hover:text-green-800">
                              Update
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
