// Modified API route to work without Cloudflare dependencies in development
import { NextRequest, NextResponse } from 'next/server';

// Mock data for a shop
const shop = {
  id: 1,
  name: 'European Auto Specialists',
  email: 'info@euroautospecialists.co.nz',
  phone: '09-123-4567',
  address: '123 Auto Lane, Auckland',
  isMtaApproved: true
};

// Mock data for leads
const leads = [
  { 
    id: 1, 
    referenceCode: 'EAF12345', 
    customerName: 'John Smith',
    customerEmail: 'john.smith@example.com',
    customerPhone: '021-555-1234',
    vehicleBrand: 'Mercedes-Benz',
    vehicleModel: 'C-Class',
    vehicleYear: '2018',
    repairType: 'Service & Maintenance',
    description: 'Regular service and oil change needed',
    status: 'Completed',
    date: '2025-04-20',
    isCompleted: true,
    commission: 45.00
  },
  { 
    id: 2, 
    referenceCode: 'EAF12346', 
    customerName: 'Sarah Johnson',
    customerEmail: 'sarah.j@example.com',
    customerPhone: '022-555-5678',
    vehicleBrand: 'BMW',
    vehicleModel: '3 Series',
    vehicleYear: '2020',
    repairType: 'Brakes & Suspension',
    description: 'Squeaking noise when braking',
    status: 'In Progress',
    date: '2025-04-23',
    isCompleted: false,
    commission: null
  },
  { 
    id: 3, 
    referenceCode: 'EAF12347', 
    customerName: 'David Williams',
    customerEmail: 'david.w@example.com',
    customerPhone: '027-555-9012',
    vehicleBrand: 'Mercedes-Benz',
    vehicleModel: 'E-Class',
    vehicleYear: '2019',
    repairType: 'Electrical & Electronics',
    description: 'Dashboard warning lights coming on intermittently',
    status: 'New',
    date: '2025-04-25',
    isCompleted: false,
    commission: null
  }
];

// API endpoint for shop dashboard to view and manage their leads
export async function GET(request: NextRequest) {
  try {
    // Get shop ID from query parameters
    const { searchParams } = new URL(request.url);
    const shopId = searchParams.get('shopId');
    
    if (!shopId) {
      return NextResponse.json({ 
        success: false, 
        error: 'Shop ID is required' 
      }, { status: 400 });
    }
    
    // In a real implementation, we would check if the shop exists
    // For now, we'll just return our mock shop and leads
    
    // Calculate statistics
    const newLeadsCount = leads.filter(lead => lead.status === 'New').length;
    const inProgressLeadsCount = leads.filter(lead => lead.status === 'In Progress').length;
    const completedLeadsCount = leads.filter(lead => lead.isCompleted).length;
    const totalCommission = leads
      .filter(lead => lead.commission !== null)
      .reduce((sum, lead) => sum + (lead.commission || 0), 0);
    
    return NextResponse.json({ 
      success: true, 
      data: { 
        shop,
        leads,
        stats: {
          newLeads: newLeadsCount,
          inProgressLeads: inProgressLeadsCount,
          completedLeads: completedLeadsCount,
          totalCommission: totalCommission
        }
      } 
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to fetch shop leads' 
    }, { status: 500 });
  }
}

// API endpoint for shop to update lead status
export async function PUT(request: NextRequest) {
  try {
    const data = await request.json();
    const { leadId, status, shopId } = data;
    
    if (!leadId || !status || !shopId) {
      return NextResponse.json({ 
        success: false, 
        error: 'Lead ID, status, and shop ID are required' 
      }, { status: 400 });
    }
    
    // In a real implementation, this would update the database
    // For now, we'll just return success
    
    return NextResponse.json({ 
      success: true, 
      data: { 
        message: 'Lead status updated successfully',
        leadId,
        status
      } 
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to update lead status' 
    }, { status: 500 });
  }
}
