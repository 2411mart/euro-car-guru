// Modified API route to work without Cloudflare dependencies in development
import { NextRequest, NextResponse } from 'next/server';

// Mock data for leads
const leads = [
  { 
    id: 1, 
    referenceCode: 'EAF12345', 
    customerName: 'John Smith',
    vehicleBrand: 'Mercedes-Benz',
    vehicleModel: 'C-Class',
    repairType: 'Service & Maintenance',
    shopName: 'European Auto Specialists',
    status: 'Completed',
    date: '2025-04-20',
    commission: 45.00
  },
  { 
    id: 2, 
    referenceCode: 'EAF12346', 
    customerName: 'Sarah Johnson',
    vehicleBrand: 'BMW',
    vehicleModel: '3 Series',
    repairType: 'Brakes & Suspension',
    shopName: 'German Auto Care',
    status: 'In Progress',
    date: '2025-04-23',
    commission: null
  },
  { 
    id: 3, 
    referenceCode: 'EAF12347', 
    customerName: 'David Williams',
    vehicleBrand: 'Audi',
    vehicleModel: 'A4',
    repairType: 'Electrical & Electronics',
    shopName: 'Audi & VW Experts',
    status: 'Quoted',
    date: '2025-04-25',
    commission: null
  }
];

// API endpoint for verifying completed jobs and calculating commissions
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { referenceCode } = data;
    
    if (!referenceCode) {
      return NextResponse.json({ 
        success: false, 
        error: 'Reference code is required' 
      }, { status: 400 });
    }
    
    // Check if lead exists in our mock data
    const lead = leads.find(l => l.referenceCode === referenceCode);
    
    if (!lead) {
      return NextResponse.json({ 
        success: false, 
        error: 'Invalid reference code' 
      }, { status: 404 });
    }
    
    // Check if lead is already completed
    if (lead.status === 'Completed') {
      return NextResponse.json({ 
        success: false, 
        error: 'Job already marked as completed' 
      }, { status: 400 });
    }
    
    // Calculate commission (in a real system, this might be based on repair type, vehicle brand, etc.)
    // For this example, we'll use a simple fixed amount
    const commissionAmount = 45.00;
    
    // In a real implementation, this would update the database
    // For now, we'll just return success with the commission amount
    
    return NextResponse.json({ 
      success: true, 
      data: { 
        message: 'Job verified successfully',
        commissionAmount,
        referenceCode
      } 
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to verify job' 
    }, { status: 500 });
  }
}

// API endpoint for getting lead statistics
export async function GET(request: NextRequest) {
  try {
    // Calculate statistics from our mock data
    const totalLeads = leads.length;
    const completedJobs = leads.filter(lead => lead.status === 'Completed').length;
    const totalCommission = leads
      .filter(lead => lead.commission !== null)
      .reduce((sum, lead) => sum + (lead.commission || 0), 0);
    
    return NextResponse.json({ 
      success: true, 
      data: { 
        totalLeads,
        completedJobs,
        totalCommission,
        recentLeads: leads
      } 
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to fetch lead statistics' 
    }, { status: 500 });
  }
}
