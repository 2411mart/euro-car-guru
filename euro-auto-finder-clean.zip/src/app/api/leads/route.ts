// Modified API route to work without Cloudflare dependencies in development
import { NextRequest, NextResponse } from 'next/server';

// Mock data for brands
const brands = [
  { id: 1, name: 'Mercedes-Benz', slug: 'mercedes', description: 'Luxury German automotive brand known for premium vehicles and innovative technology.' },
  { id: 2, name: 'BMW', slug: 'bmw', description: 'Bavarian Motor Works, renowned for performance luxury vehicles with dynamic driving characteristics.' },
  { id: 3, name: 'Audi', slug: 'audi', description: 'German automobile manufacturer known for sophisticated design, advanced engineering, and Quattro all-wheel drive.' },
  { id: 4, name: 'Volkswagen', slug: 'volkswagen', description: 'Europe\'s largest automaker known for reliable, practical, and well-engineered vehicles.' }
];

// Mock data for repair types
const repairTypes = [
  { id: 1, name: 'Service & Maintenance', slug: 'service-maintenance', description: 'Regular servicing and maintenance to keep your vehicle in optimal condition.' },
  { id: 2, name: 'Brakes & Suspension', slug: 'brakes-suspension', description: 'Repair and replacement of brake systems and suspension components.' },
  { id: 3, name: 'Engine & Transmission', slug: 'engine-transmission', description: 'Diagnostics and repair of engine and transmission systems.' },
  { id: 4, name: 'Electrical & Electronics', slug: 'electrical-electronics', description: 'Troubleshooting and repair of electrical systems and electronic components.' },
  { id: 5, name: 'Air Conditioning', slug: 'air-conditioning', description: 'Maintenance and repair of vehicle climate control systems.' },
  { id: 6, name: 'Diagnostics', slug: 'diagnostics', description: 'Comprehensive vehicle diagnostics to identify issues and recommend solutions.' }
];

export async function GET(request: NextRequest) {
  try {
    // Return the mock data
    return NextResponse.json({ 
      success: true, 
      data: { 
        brands,
        repairTypes
      } 
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to fetch data' 
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { 
      shopId, 
      brandId, 
      repairTypeId, 
      customerName, 
      customerEmail, 
      customerPhone, 
      vehicleModel, 
      vehicleYear, 
      description, 
      preferredContact, 
      preferredTimeframe 
    } = data;
    
    // Generate a unique reference code
    const referenceCode = generateReferenceCode();
    
    // In a real implementation, this would save to the database
    // For now, we'll just return success with the reference code
    
    return NextResponse.json({ 
      success: true, 
      data: { 
        referenceCode,
        message: 'Lead created successfully' 
      } 
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to create lead' 
    }, { status: 500 });
  }
}

// Helper function to generate a unique reference code
function generateReferenceCode() {
  const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed similar looking characters
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}
