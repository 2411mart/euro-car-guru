-- Euro Auto Finder Database Schema

-- Drop tables if they exist (for clean reset)
DROP TABLE IF EXISTS leads;
DROP TABLE IF EXISTS shops;
DROP TABLE IF EXISTS repair_types;
DROP TABLE IF EXISTS brands;

-- Create brands table
CREATE TABLE brands (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  logo_url TEXT,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create repair_types table
CREATE TABLE repair_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create shops table
CREATE TABLE shops (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  postal_code TEXT,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  website TEXT,
  rating DECIMAL(2,1) DEFAULT 0,
  is_mta_approved BOOLEAN DEFAULT FALSE,
  is_franchise BOOLEAN DEFAULT FALSE,
  logo_url TEXT,
  hours TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create shop_brands junction table
CREATE TABLE shop_brands (
  shop_id INTEGER NOT NULL,
  brand_id INTEGER NOT NULL,
  PRIMARY KEY (shop_id, brand_id),
  FOREIGN KEY (shop_id) REFERENCES shops(id) ON DELETE CASCADE,
  FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE CASCADE
);

-- Create shop_repair_types junction table
CREATE TABLE shop_repair_types (
  shop_id INTEGER NOT NULL,
  repair_type_id INTEGER NOT NULL,
  PRIMARY KEY (shop_id, repair_type_id),
  FOREIGN KEY (shop_id) REFERENCES shops(id) ON DELETE CASCADE,
  FOREIGN KEY (repair_type_id) REFERENCES repair_types(id) ON DELETE CASCADE
);

-- Create leads table
CREATE TABLE leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reference_code TEXT NOT NULL UNIQUE,
  shop_id INTEGER NOT NULL,
  brand_id INTEGER NOT NULL,
  repair_type_id INTEGER NOT NULL,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  vehicle_model TEXT,
  vehicle_year TEXT,
  description TEXT,
  preferred_contact TEXT,
  preferred_timeframe TEXT,
  status TEXT DEFAULT 'new',
  is_completed BOOLEAN DEFAULT FALSE,
  commission_amount DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (shop_id) REFERENCES shops(id) ON DELETE CASCADE,
  FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE CASCADE,
  FOREIGN KEY (repair_type_id) REFERENCES repair_types(id) ON DELETE CASCADE
);

-- Create shop_reviews table
CREATE TABLE shop_reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shop_id INTEGER NOT NULL,
  customer_name TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (shop_id) REFERENCES shops(id) ON DELETE CASCADE
);

-- Insert initial data for brands
INSERT INTO brands (name, slug, description) VALUES
('Mercedes-Benz', 'mercedes', 'Luxury German automotive brand known for premium vehicles and innovative technology.'),
('BMW', 'bmw', 'Bavarian Motor Works, renowned for performance luxury vehicles with dynamic driving characteristics.'),
('Audi', 'audi', 'German automobile manufacturer known for sophisticated design, advanced engineering, and Quattro all-wheel drive.'),
('Volkswagen', 'volkswagen', 'Europe''s largest automaker known for reliable, practical, and well-engineered vehicles.');

-- Insert initial data for repair types
INSERT INTO repair_types (name, slug, description) VALUES
('Service & Maintenance', 'service-maintenance', 'Regular servicing and maintenance to keep your vehicle in optimal condition.'),
('Brakes & Suspension', 'brakes-suspension', 'Repair and replacement of brake systems and suspension components.'),
('Engine & Transmission', 'engine-transmission', 'Diagnostics and repair of engine and transmission systems.'),
('Electrical & Electronics', 'electrical-electronics', 'Troubleshooting and repair of electrical systems and electronic components.'),
('Air Conditioning', 'air-conditioning', 'Maintenance and repair of vehicle climate control systems.'),
('Diagnostics', 'diagnostics', 'Comprehensive vehicle diagnostics to identify issues and recommend solutions.');
